// src/pages/admin/AdminDashboard.tsx
import { useEffect, useState } from "react";
import { adminApi, AdminWine } from "../../services/admin";

type Tab = "wines" | "wineries" | "categories" | "orders";

export default function AdminDashboard() {
  const [tab, setTab] = useState<Tab>("wines");

  return (
    <section className="container-wide" style={{ padding: "1.5rem 0 3rem" }}>
      <h1 className="page-title" style={{ fontFamily: "Playfair Display,serif" }}>Admin</h1>

      <div style={{ display: "flex", gap: "0.75rem", margin: "0.5rem 0 1rem" }}>
        <button className={`pill ${tab==="wines" ? "active":""}`} onClick={() => setTab("wines")}>Wines</button>
        <button className={`pill ${tab==="wineries" ? "active":""}`} onClick={() => setTab("wineries")}>Wineries</button>
        <button className={`pill ${tab==="categories" ? "active":""}`} onClick={() => setTab("categories")}>Categories</button>
        <button className={`pill ${tab==="orders" ? "active":""}`} onClick={() => setTab("orders")}>Orders</button>
      </div>

      {tab === "wines" && <WinesTab />}
      {tab === "wineries" && <Placeholder title="Wineries" />}
      {tab === "categories" && <Placeholder title="Categories" />}
      {tab === "orders" && <Placeholder title="Orders" />}
    </section>
  );
}

function Placeholder({ title }: { title: string }) {
  return (
    <article className="card" style={{ padding: "1rem" }}>
      <h3 style={{ marginTop: 0 }}>{title}</h3>
      <p>TODO…</p>
    </article>
  );
}

function WinesTab() {
  const [rows, setRows] = useState<AdminWine[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await adminApi.listWines();
        if (!mounted) return;
        setRows(data);
      } catch (e: any) {
        console.error("WINES TAB ERROR", e?.response || e);
        const msg =
          e?.response?.data?.message ||
          e?.message ||
          `Failed to load wines.`;
        setErr(msg);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <article className="card" style={{ padding: 0 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0.8rem 1rem" }}>
        <h3 style={{ margin: 0 }}>Wines</h3>
        <button className="btn-primary">Add wine</button>
      </div>

      {loading ? (
        <div style={{ padding: "1rem" }}>Loading…</div>
      ) : err ? (
        <div style={{ padding: "1rem", color: "var(--danger,#a00)" }}>
          {err}
          <div style={{ marginTop: ".5rem", fontSize: 12, color: "#666" }}>
            (Proveri Network tab: ruta, status, CORS, token)
          </div>
        </div>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#12161c", color: "#d0d6e1" }}>
                <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>Name</th>
                <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>Year</th>
                <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>Price</th>
                <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>Category</th>
                <th style={{ textAlign: "left", padding: "0.75rem 1rem" }}>Winery</th>
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td colSpan={5} style={{ padding: "1rem", color: "#666" }}>
                    No wines
                  </td>
                </tr>
              ) : (
                rows.map((w) => (
                  <tr key={w.wineId} style={{ borderTop: "1px solid #eee" }}>
                    <td style={{ padding: "0.7rem 1rem" }}>{w.name}</td>
                    <td style={{ padding: "0.7rem 1rem" }}>{w.year ?? "—"}</td>
                    <td style={{ padding: "0.7rem 1rem" }}>{Math.round(w.price)} RSD</td>
                    <td style={{ padding: "0.7rem 1rem" }}>{w.category?.name ?? "—"}</td>
                    <td style={{ padding: "0.7rem 1rem" }}>{w.winery?.name ?? "—"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </article>
  );
}


